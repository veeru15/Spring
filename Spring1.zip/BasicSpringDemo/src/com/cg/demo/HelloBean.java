package com.cg.demo;

public class HelloBean {
	public String helloworld(){
		return "Welcome to Spring";
	}

}
