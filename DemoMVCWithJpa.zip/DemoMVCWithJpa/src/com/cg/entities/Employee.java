package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;






import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="empspring")
public class Employee {
	@Id
	@Column(name="EMPNO")
	@NotNull(message="Empno is madatory")
	private Integer empno;
	@Column(name="ENAME")
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="[A-Za-z]{3,15}", message="Name should contain min 3 and max 15 letters")
	private String ename;
	@Column(name="AGE")
	@NotNull(message="age is mandatory")
	private int age;
	public Employee() {
		
	}
	@Override
	public String toString() {
		return super.toString();
	}
	public Integer getEmpno() {
		return empno;
	}
	public void setEmpno(Integer empno) {
		this.empno = empno;
	}
	public String getename() {
		return ename;
	}
	public void setename(String ename) {
		this.ename = ename;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(Integer empno, String ename, int age) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.age = age;
	}
	
}
