package com.cg.dao;

import com.cg.entities.Employee;

public interface EmployeeDao {
	int insertEmployee(Employee emp);
}
